
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
using namespace  std;


  void print_menu (){
      cout << "---------------------------------------"<< endl;
      cout << "welcome to Auto Nation used cars "<< endl;
      cout << " Enter  m- check the models"<< endl;
      cout << "enter  p - check the prices "<< endl;
      cout << "Enter  q - exit this menu "<< endl;
      cout << "---------------------------------------"<< endl;
      cout << "Please enter your choice"<< endl;
  }
  void check_brand(vector<string> car_model,vector<string> car_type,vector<int> car_year){
    cout<<" This is our Inventory:"<< endl;
    for(int i=0; i < car_model(i); i++){
  cout << car_model(i) <<" "<<car_type(i)<< " " << car_year(i) << endl;
      
    }
  
}
  void check_price(vector<string> car_model,vector<string> car_type,vector<int> car_year, vector<int> price_car){
  cout << "This are the prices"<< endl;
    for ()
  }
  void   initialize_data(vector<string>& car_model,vector<string>& car_type,vector<int>& car_year, vector<int>& price_car){
    ifstream fin;
    string temp_string;
    int number;
    
    fin.open("project.txt");
   if (fin.is_open()){
  while (!fin.eof()){
    
    fin>> temp_string;           
    car_model.push_back(temp_string);

    fin>> temp_string;
    car_type.push_back(temp_string);
    
    fin>> number;
    car_year.push_back(number);
   
    fin >> number;
    price_car.push_back(number);
  
  }    
  
     fin.close();
   cout << "Initialized " << car_model.size() <<endl;
  }
  else{
  cout << " The file did not open "<< endl;
  }
    
  }



  int main(){
  char userInput;
    
  vector<string>car_model;
  vector<string>car_type;
  vector<int> car_year;
  vector<int>price_car;

  initialize_data(car_model,car_type,car_year,price_car);
    
    do {
      print_menu();
      cin >> userInput;
      switch(userInput){
      
      case 'm':
      check_brand(car_model,car_type,car_year);
      break;

      case 'p':
      check_price(car_model,car_type,car_year, price_car);

      break;

      case 'q':
        
      cout << "Bye!!!!! Thanks"<< endl;
        
      break;

      default:
        cout << "Invalid option, please try again"<< endl;
        }
      
      
    } while(userInput != 'q');



    return 0;
  }