
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
using namespace  std;


  void print_menu (){
      cout << "---------------------------------------"<< endl;
      cout << "welcome to Auto Nation used cars "<< endl;
      cout << " Enter  m- check the models"<< endl;
      cout << "enter  p - check the prices "<< endl;
      cout << "Enter  q - exit this menu "<< endl;
      cout << "---------------------------------------"<< endl;
      cout << "Please enter your choice"<< endl;
  }
  void check_brand(){
    cout<<" This is our Inventory:"<< endl;
  
}
  void check_price(){
  cout << "This are the prices"<< endl;
    
  }
  void   initialize_data(vector<string>& car_model,vector<int>& car_year,vector<int>& price_car){
    ifstream fin;
    string save;
    int number;
    
    fin.open("project.txt");
   if(fin.is_open()){
  while (!fin.eof()){
    fin>> save;
    car_model.push_back(save);
    fin>> number;
   car_year.push_back(number);
    fin >> number;
    price_car.push_back(number);
  
  }    
  fin.close();
   cout << "Initialized" << car_model.size() <<endl;
  }
  else{
  cout << " The file did not open"<< endl;
  }
    
  }



  int main(){
  char userInput;
    
  vector<string>car_model;
  vector<int> car_year;
  vector<int>price_car;

  initialize_data(car_model,car_year,price_car);
    
    do {
      print_menu();
      cin >> userInput;
      switch(userInput){
      
      case 'm':
      check_brand();
      break;

      case 'p':
      check_price();

      break;

      case 'q':
        
      cout << "Bye!!!!! Thanks"<< endl;
        
      break;

      default:
        cout << "Invalid option, please try again"<< endl;
        }
      
      
    } while(userInput != 'q');



    return 0;
  }